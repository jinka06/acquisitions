import { getDb } from '../config/db.js'

export async function createUsersTable() {
    const db = await getDb()
    await db.exec(`CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      name TEXT NOT NULL UNIQUE,
      email TEXT NOT NULL UNIQUE,
      password TEXT NOT NULL UNIQUE,
      role TEXT NOT NULL UNIQUE,
      created_at TEXT NOT NULL DEFAULT (datatime('now')),
      updated_at TEXT NOT NULL DEFAULT (datatime('now'))
    )`)
    console.log('Table created successfully');
}

export async function createUser({ name, email, password, role }) {
  const db = await getDb();
  return db.run(
    `INSERT INTO users (name, email, password, role) VALUES (?, ?, ?, ?)`,
    [name, email, password, role]
  );
}