import { getDb } from '../config/db.js';
import { createUsersTable, createUser } from '../models/user.model.js';

const users = [
  {
    name: 'Alice',
    email: 'alice@example.com',
    password: 'hashed_password_1',
    role: 'admin',
  },
  {
    name: 'Bob',
    email: 'bob@example.com',
    password: 'hashed_password_2',
    role: 'user',
  },
];

async function seedTable() {
  await createUsersTable();
  const db = await getDb();
  try {
    await db.exec('BEGIN TRANSACTION');
    for (const user of users) {
      await createUser(user)
    }
    await db.exec('COMMIT');
    console.log('Users seeded successfully');
  } catch (error) {
    await db.exec('ROLLBACK');
    console.error('Error seeding users:', error.message);
  } finally {
    await db.close();
  }
}

seedTable();